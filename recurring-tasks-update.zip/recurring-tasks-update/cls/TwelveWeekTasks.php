<?php
namespace eBizIndia;

/**
 * TwelveWeekTasks data access class with encryption support
 * Handles CRUD operations for 12-week tasks with automatic encryption/decryption
 */
class TwelveWeekTasks {
    
    /**
     * Save a task with automatic encryption of sensitive fields
     * @param array $data Task data including title, goal_id, week_number
     * @return int|false Task ID on success, false on failure
     */
    public static function saveTask($data) {
        try {
            // Validate required fields
            if (empty($data['title'])) {
                throw new \Exception("Task title is required");
            }
            
            if (empty($data['goal_id']) || empty($data['week_number'])) {
                throw new \Exception("Goal ID and week number are required");
            }
            
            if ($data['week_number'] < 1 || $data['week_number'] > 12) {
                throw new \Exception("Week number must be between 1 and 12");
            }
            
            // Encrypt title if encryption is available
            $encryptedData = $data;
            if (isset($data['title']) && !empty($data['title']) && Encryption::isAvailable()) {
                $encrypted = Encryption::encryptShared($data['title'], 'twelve_week_tasks');
                if ($encrypted === false) {
                    throw new \Exception("Failed to encrypt task title");
                }
                $encryptedData['title'] = $encrypted;
                $encryptedData['is_encrypted'] = 1;
                $encryptedData['encryption_key_id'] = 'twelve_week_tasks_shared_' . date('Ym');
            } else {
                $encryptedData['is_encrypted'] = 0;
                $encryptedData['encryption_key_id'] = null;
            }
            
            $conn = PDOConn::getInstance();
            
            if (isset($data['id']) && !empty($data['id'])) {
                // Update existing task
                $sql = "UPDATE tasks SET
                        title = :title,
                        week_number = :week_number,
                        weekly_target = :weekly_target,
                        is_recurring = :is_recurring,
                        is_encrypted = :is_encrypted,
                        encryption_key_id = :encryption_key_id,
                        updated_at = CURRENT_TIMESTAMP
                        WHERE id = :id AND goal_id = :goal_id";

                $params = [
                    ':id' => $data['id'],
                    ':title' => $encryptedData['title'],
                    ':week_number' => $encryptedData['week_number'],
                    ':weekly_target' => $encryptedData['weekly_target'] ?? 3,
                    ':is_recurring' => $encryptedData['is_recurring'] ?? 0,
                    ':goal_id' => $encryptedData['goal_id'],
                    ':is_encrypted' => $encryptedData['is_encrypted'],
                    ':encryption_key_id' => $encryptedData['encryption_key_id']
                ];

                $stmt = $conn->prepare($sql);
                $result = $stmt->execute($params);

                return $result ? $data['id'] : false;

            } else {
                // Insert new task
                $isRecurring = isset($encryptedData['is_recurring']) ? (int)$encryptedData['is_recurring'] : 0;

                $sql = "INSERT INTO tasks (goal_id, week_number, title, weekly_target, is_recurring, is_encrypted, encryption_key_id)
                        VALUES (:goal_id, :week_number, :title, :weekly_target, :is_recurring, :is_encrypted, :encryption_key_id)";

                $params = [
                    ':goal_id' => $encryptedData['goal_id'],
                    ':week_number' => $encryptedData['week_number'],
                    ':title' => $encryptedData['title'],
                    ':weekly_target' => $encryptedData['weekly_target'] ?? 3,
                    ':is_recurring' => $isRecurring,
                    ':is_encrypted' => $encryptedData['is_encrypted'],
                    ':encryption_key_id' => $encryptedData['encryption_key_id']
                ];

                $stmt = $conn->prepare($sql);
                $result = $stmt->execute($params);

                if (!$result) {
                    return false;
                }

                $taskId = $conn->lastInsertId();

                // Log is_recurring value for debugging
                error_log("SaveTask: Task created with ID $taskId, is_recurring = $isRecurring");

                // If task is recurring, create copies for future weeks
                if ($isRecurring == 1 && !isset($data['_skip_recurring'])) {
                    error_log("SaveTask: Calling createRecurringCopies for task $taskId");
                    self::createRecurringCopies($encryptedData, $taskId);
                } else {
                    error_log("SaveTask: NOT creating recurring copies. is_recurring=$isRecurring, _skip_recurring=" . (isset($data['_skip_recurring']) ? 'true' : 'false'));
                }

                return $taskId;
            }
            
        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::saveTask',
                'data' => $data,
                'error' => $e->getMessage()
            ], $e);
            return false;
        }
    }
    
    /**
     * Get tasks for a goal with automatic decryption
     * @param int $goalId Goal ID
     * @param int|null $weekNumber Optional week filter
     * @return array Array of tasks with decrypted data
     */
    public static function getTasks($goalId, $weekNumber = null) {
        try {
            $sql = "SELECT id, goal_id, week_number, title, weekly_target, is_recurring,
                           mon, tue, wed, thu, fri, sat, sun,
                           is_encrypted, encryption_key_id, created_at, updated_at
                    FROM tasks WHERE goal_id = :goal_id";
            $params = [':goal_id' => $goalId];

            if ($weekNumber !== null) {
                $sql .= " AND week_number = :week_number";
                $params[':week_number'] = $weekNumber;
            }

            $sql .= " ORDER BY week_number, created_at";

            $stmt = PDOConn::query($sql, $params);
            $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // Decrypt data if encrypted
            foreach ($results as &$row) {
                if (isset($row['is_encrypted']) && $row['is_encrypted'] == 1) {
                    $decrypted = Encryption::decryptShared($row['title'], 'twelve_week_tasks');
                    if ($decrypted !== false) {
                        $row['title'] = $decrypted;
                    }
                }
            }

            return $results;

        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::getTasks',
                'goal_id' => $goalId,
                'week_number' => $weekNumber,
                'error' => $e->getMessage()
            ], $e);
            return [];
        }
    }
    
    /**
     * Get tasks for a specific week across all goals for a user
     * @param int $userId User ID
     * @param int $cycleId Cycle ID
     * @param int $weekNumber Week number (1-12)
     * @return array Array of tasks organized by category and goal
     */
    public static function getTasksForWeek($userId, $cycleId, $weekNumber) {
        try {
            $sql = "SELECT t.id, t.goal_id, t.week_number, t.title, t.weekly_target, t.is_recurring,
                           t.mon, t.tue, t.wed, t.thu, t.fri, t.sat, t.sun,
                           t.is_encrypted, t.encryption_key_id, t.created_at, t.updated_at,
                           g.title as goal_title, g.id as goal_id,
                           c.name as category_name, c.color_code, c.sort_order as category_sort
                    FROM tasks t
                    JOIN goals g ON t.goal_id = g.id
                    JOIN categories c ON g.category_id = c.id
                    WHERE g.user_id = :user_id AND g.cycle_id = :cycle_id AND t.week_number = :week_number
                    ORDER BY c.sort_order, c.name, g.title, t.created_at";

            $stmt = PDOConn::query($sql, [
                ':user_id' => $userId,
                ':cycle_id' => $cycleId,
                ':week_number' => $weekNumber
            ]);

            $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);

            // Decrypt data if encrypted
            foreach ($results as &$row) {
                if (isset($row['is_encrypted']) && $row['is_encrypted'] == 1) {
                    $decrypted = Encryption::decryptShared($row['title'], 'twelve_week_tasks');
                    if ($decrypted !== false) {
                        $row['title'] = $decrypted;
                    }
                }
            }

            return $results;

        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::getTasksForWeek',
                'user_id' => $userId,
                'cycle_id' => $cycleId,
                'week_number' => $weekNumber,
                'error' => $e->getMessage()
            ], $e);
            return [];
        }
    }
    
    /**
     * Update task progress for a specific day
     * @param int $taskId Task ID
     * @param string $day Day of week (mon, tue, wed, thu, fri, sat, sun)
     * @param int $completed Completion status (0 or 1)
     * @param int $userId User ID (for security)
     * @return bool Success status
     */
    public static function updateTaskProgress($taskId, $day, $completed, $userId) {
        try {
            // Validate day
            $validDays = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
            if (!in_array($day, $validDays)) {
                throw new \Exception("Invalid day: $day");
            }
            
            // Validate completion status
            $completed = $completed ? 1 : 0;
            
            // Verify task belongs to user (security check)
            $check_sql = "SELECT t.id FROM tasks t 
                         JOIN goals g ON t.goal_id = g.id 
                         WHERE t.id = :task_id AND g.user_id = :user_id";
            
            $check_stmt = PDOConn::query($check_sql, [
                ':task_id' => $taskId,
                ':user_id' => $userId
            ]);
            
            if (!$check_stmt->fetch()) {
                throw new \Exception("Task not found or access denied");
            }
            
            // Update progress
            $sql = "UPDATE tasks SET $day = :completed, updated_at = CURRENT_TIMESTAMP WHERE id = :task_id";
            
            $stmt = PDOConn::query($sql, [
                ':completed' => $completed,
                ':task_id' => $taskId
            ]);
            
            return $stmt->rowCount() > 0;
            
        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::updateTaskProgress',
                'task_id' => $taskId,
                'day' => $day,
                'completed' => $completed,
                'user_id' => $userId,
                'error' => $e->getMessage()
            ], $e);
            return false;
        }
    }
    
    /**
     * Get a single task by ID with automatic decryption
     * @param int $taskId Task ID
     * @param int $userId User ID (for security)
     * @return array|false Task data or false if not found
     */
    public static function getTask($taskId, $userId) {
        try {
            $sql = "SELECT t.id, t.goal_id, t.week_number, t.title, t.weekly_target, t.is_recurring,
                           t.mon, t.tue, t.wed, t.thu, t.fri, t.sat, t.sun,
                           t.is_encrypted, t.encryption_key_id, t.created_at, t.updated_at,
                           g.title as goal_title, g.user_id
                    FROM tasks t
                    JOIN goals g ON t.goal_id = g.id
                    WHERE t.id = :task_id AND g.user_id = :user_id";

            $stmt = PDOConn::query($sql, [
                ':task_id' => $taskId,
                ':user_id' => $userId
            ]);

            $result = $stmt->fetch(\PDO::FETCH_ASSOC);

            if ($result) {
                // Decrypt data if encrypted
                if (isset($result['is_encrypted']) && $result['is_encrypted'] == 1) {
                    $decrypted = Encryption::decryptShared($result['title'], 'twelve_week_tasks');
                    if ($decrypted !== false) {
                        $result['title'] = $decrypted;
                    }
                }
            }

            return $result;

        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::getTask',
                'task_id' => $taskId,
                'user_id' => $userId,
                'error' => $e->getMessage()
            ], $e);
            return false;
        }
    }
    
    /**
     * Delete a task
     * @param int $taskId Task ID
     * @param int $userId User ID (for security)
     * @return bool Success status
     */
    public static function deleteTask($taskId, $userId) {
        try {
            // Verify task belongs to user (security check)
            $check_sql = "SELECT t.id FROM tasks t 
                         JOIN goals g ON t.goal_id = g.id 
                         WHERE t.id = :task_id AND g.user_id = :user_id";
            
            $check_stmt = PDOConn::query($check_sql, [
                ':task_id' => $taskId,
                ':user_id' => $userId
            ]);
            
            if (!$check_stmt->fetch()) {
                return false; // Task not found or access denied
            }
            
            // Delete the task
            $sql = "DELETE FROM tasks WHERE id = :task_id";
            $stmt = PDOConn::query($sql, [':task_id' => $taskId]);
            
            return $stmt->rowCount() > 0;
            
        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::deleteTask',
                'task_id' => $taskId,
                'user_id' => $userId,
                'error' => $e->getMessage()
            ], $e);
            return false;
        }
    }
    
    /**
     * Get task count for a goal
     * @param int $goalId Goal ID
     * @return int Task count
     */
    public static function getTaskCount($goalId) {
        try {
            $sql = "SELECT COUNT(*) as count FROM tasks WHERE goal_id = :goal_id";
            $stmt = PDOConn::query($sql, [':goal_id' => $goalId]);

            $result = $stmt->fetch(\PDO::FETCH_ASSOC);
            return $result ? (int)$result['count'] : 0;

        } catch (\Exception $e) {
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::getTaskCount',
                'goal_id' => $goalId,
                'error' => $e->getMessage()
            ], $e);
            return 0;
        }
    }

    /**
     * Create recurring copies of a task for future weeks in the current cycle
     * @param array $encryptedData Already encrypted task data
     * @param int $originalTaskId ID of the original task
     * @return void
     */
    private static function createRecurringCopies($encryptedData, $originalTaskId) {
        try {
            // Log that we're attempting to create recurring copies
            error_log("Creating recurring copies for task ID: $originalTaskId");

            // Get the cycle for this goal to determine current week
            $goalSql = "SELECT g.cycle_id, c.start_date, c.end_date
                       FROM goals g
                       JOIN cycles c ON g.cycle_id = c.id
                       WHERE g.id = :goal_id";

            $goalStmt = PDOConn::query($goalSql, [':goal_id' => $encryptedData['goal_id']]);
            $goalData = $goalStmt->fetch(\PDO::FETCH_ASSOC);

            if (!$goalData) {
                error_log("Recurring copies: Goal or cycle not found for goal_id: " . $encryptedData['goal_id']);
                return; // Goal or cycle not found
            }

            // Calculate current week number
            $cycle = [
                'start_date' => $goalData['start_date'],
                'end_date' => $goalData['end_date']
            ];

            // Call the global function with proper namespace
            $currentWeek = \eBizIndia\getCurrentWeekNumber($cycle);
            error_log("Recurring copies: Current week is: $currentWeek");

            // If cycle hasn't started or is completed, don't create copies
            if ($currentWeek <= 0 || $currentWeek > 12) {
                error_log("Recurring copies: Cycle not active (week: $currentWeek)");
                return;
            }

            // Determine starting week for copies
            // Start from the later of: task's week number or current week
            $startWeek = max((int)$encryptedData['week_number'], $currentWeek);
            $endWeek = 12; // Always 12 weeks in a cycle

            error_log("Recurring copies: Will create from week $startWeek to $endWeek");

            // Create copies for each future week
            $copiesCreated = 0;
            for ($week = $startWeek; $week <= $endWeek; $week++) {
                // Skip the original week
                if ($week == $encryptedData['week_number']) {
                    continue;
                }

                // Check if task already exists to prevent duplicates
                $checkSql = "SELECT id FROM tasks
                            WHERE goal_id = :goal_id
                            AND week_number = :week_number
                            AND title = :title
                            AND is_recurring = 1";

                $checkStmt = PDOConn::query($checkSql, [
                    ':goal_id' => $encryptedData['goal_id'],
                    ':week_number' => $week,
                    ':title' => $encryptedData['title']
                ]);

                if ($checkStmt->fetch()) {
                    error_log("Recurring copies: Task already exists for week $week, skipping");
                    continue; // Task already exists, skip
                }

                // Insert copy with fresh completion flags (all days = 0)
                $copySql = "INSERT INTO tasks
                           (goal_id, week_number, title, weekly_target, is_recurring,
                            mon, tue, wed, thu, fri, sat, sun,
                            is_encrypted, encryption_key_id)
                           VALUES
                           (:goal_id, :week_number, :title, :weekly_target, :is_recurring,
                            0, 0, 0, 0, 0, 0, 0,
                            :is_encrypted, :encryption_key_id)";

                $copyParams = [
                    ':goal_id' => $encryptedData['goal_id'],
                    ':week_number' => $week,
                    ':title' => $encryptedData['title'],
                    ':weekly_target' => $encryptedData['weekly_target'] ?? 3,
                    ':is_recurring' => 1,
                    ':is_encrypted' => $encryptedData['is_encrypted'],
                    ':encryption_key_id' => $encryptedData['encryption_key_id']
                ];

                PDOConn::query($copySql, $copyParams);
                $copiesCreated++;
                error_log("Recurring copies: Created copy for week $week");
            }

            error_log("Recurring copies: Successfully created $copiesCreated copies");

        } catch (\Exception $e) {
            error_log("Recurring copies ERROR: " . $e->getMessage());
            error_log("Recurring copies ERROR trace: " . $e->getTraceAsString());
            ErrorHandler::logError([
                'function' => 'TwelveWeekTasks::createRecurringCopies',
                'task_id' => $originalTaskId,
                'error' => $e->getMessage()
            ], $e);
            // Don't throw - recurring copies are a nice-to-have feature
            // If they fail, at least the original task was saved
        }
    }
}