RECURRING TASKS FEATURE - FILE UPDATE PACKAGE
============================================

This package contains all files updated to implement the recurring tasks feature
for the 12-week goal tracking system.

DEPLOYMENT INSTRUCTIONS:
-----------------------
1. Read DEPLOYMENT_PLAN.md for complete deployment strategy
2. Back up your database before running migrations
3. Run the migration: mysql -u username -p database_name < migrations/add_recurring_field.sql
4. Copy all updated files to your production server (maintaining directory structure)
5. Run migrations/verify_deployment.php to verify the update
6. Test the feature on a non-production environment first

FILES INCLUDED:
--------------

DATABASE:
  migrations/add_recurring_field.sql
    - Adds 'is_recurring' column to tasks table
    - Creates index for performance

  migrations/README.md
    - Instructions for running database migrations

  migrations/verify_deployment.php
    - Automated verification script to check deployment success

DOCUMENTATION:
  DEPLOYMENT_PLAN.md
    - Comprehensive deployment guide with zero-downtime strategy
    - Rollback procedures
    - Testing checklist

BACKEND PHP:
  cls/TwelveWeekTasks.php
    - Updated saveTask() method to handle is_recurring field
    - Added createRecurringCopies() method to copy tasks to future weeks
    - Updated all SELECT queries to include is_recurring field

  12-week-goals.php
    - Updated 'add_task' action handler to accept is_recurring parameter
    - Returns success message when recurring tasks are created

  includes/general-func.php
    - Fixed namespace issues with PHP built-in classes (DateTime, DateTimeZone, Exception)
    - Required for getCurrentWeekNumber() function used by recurring tasks

FRONTEND TEMPLATES:
  templates/12-week-goals.tpl
    - Added recurring checkbox to Add Task modal
    - Checkbox ID: task_recurring
    - Includes descriptive help text for users

  templates/12-week-dashboard.tpl
    - Added recurring badge display for recurring tasks
    - Shows rotating icon and "Recurring" label
    - Styled with purple badge

JAVASCRIPT:
  custom-js/week-goals-12.js
    - Updated task form submission to include is_recurring field
    - Added success message display for recurring tasks
    - Added touch swipe gesture support for mobile navigation

KEY FEATURES:
------------
- When user checks "Recurring" checkbox and creates a task:
  * Task is created for the selected week
  * Task is automatically copied to all future weeks (up to week 12)
  * Copies start from max(selected_week, current_week) to week 12
  * Each copy has fresh completion flags (all days unchecked)
  * Encryption is preserved across copies
  * Duplicate prevention checks (title + goal_id + week_number + is_recurring)

- Display:
  * Recurring tasks show a purple "Recurring" badge in the dashboard
  * Badge has rotating icon for visual emphasis

- Database:
  * Backward compatible - existing tasks default to is_recurring=0
  * Safe for production deployment with zero downtime

IMPLEMENTATION NOTES:
--------------------
- All changes are in the "My Goals" module (12-week-goals.php)
- Dashboard display updated (12-week-dashboard.tpl)
- Does NOT affect Task Planning module or Weekly view
- Maintains all existing functionality
- No breaking changes

TECHNICAL DETAILS:
-----------------
- Database field: tasks.is_recurring TINYINT(1) DEFAULT 0
- Index: idx_tasks_recurring ON (is_recurring, goal_id, week_number)
- Namespace fix required for PHP DateTime classes in eBizIndia namespace
- jQuery loads before external JS to prevent "$ is not defined" errors

TESTING CHECKLIST:
-----------------
[ ] Database migration runs successfully
[ ] Recurring checkbox appears in Add Task modal
[ ] Creating recurring task copies to future weeks
[ ] Non-recurring tasks still work normally
[ ] Recurring badge appears on dashboard
[ ] No console errors in browser
[ ] Task completion works for recurring tasks
[ ] Existing tasks are not affected

SUPPORT:
--------
For questions or issues, review the DEPLOYMENT_PLAN.md file or check
the commit history on branch: claude/add-recurring-tasks-5ZheF

Last updated: 2026-01-14
