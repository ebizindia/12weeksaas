# Recurring Tasks Feature - Safe Deployment Plan

## Overview
This document provides a step-by-step plan to deploy the recurring tasks feature with ZERO downtime on a live production system.

---

## Pre-Deployment Checklist

- [ ] Backup the production database
- [ ] Test migration on a staging/development environment
- [ ] Schedule deployment during low-traffic period (recommended)
- [ ] Have rollback plan ready
- [ ] Notify team of deployment window

---

## Deployment Steps (Zero-Downtime Approach)

### Step 1: Database Migration (Execute First)
**Timing**: During maintenance window or low-traffic period
**Duration**: ~1-2 seconds (very fast)

```sql
-- Execute this on production database
-- This will NOT break existing functionality

-- Add is_recurring column with safe default
ALTER TABLE tasks
ADD COLUMN is_recurring TINYINT(1) NOT NULL DEFAULT 0
COMMENT 'Flag indicating if task should recur in future weeks (0=one-time, 1=recurring)'
AFTER weekly_target;

-- Add index for performance (can be done AFTER if needed to reduce lock time)
CREATE INDEX idx_tasks_recurring ON tasks(is_recurring, goal_id, week_number);
```

**Why this is safe:**
- Uses `DEFAULT 0` so all existing tasks automatically become non-recurring
- Old code (before deployment) doesn't query this field, so it won't break
- Table lock is very brief (~1-2 seconds for typical datasets)

**Validation:**
```sql
-- Verify field was added
DESCRIBE tasks;

-- Verify all existing tasks have is_recurring = 0
SELECT COUNT(*) FROM tasks WHERE is_recurring = 0;

-- Verify index exists
SHOW INDEX FROM tasks WHERE Key_name = 'idx_tasks_recurring';
```

---

### Step 2: Deploy Application Code (Execute Second)
**Timing**: Immediately after database migration is confirmed
**Duration**: ~30 seconds

**Files to deploy:**
1. `cls/TwelveWeekTasks.php` - Updated task management class
2. `12-week-plan-tasks.php` - Updated task planning page
3. `templates/12-week-plan-tasks.tpl` - Updated UI with recurring checkbox
4. `templates/12-week-weekly.tpl` - Updated weekly view with recurring badge

**Deployment method:**
```bash
# Option A: Direct file copy (fastest)
# Upload files via FTP/SFTP to production server

# Option B: Git pull (if using git deployment)
cd /path/to/production
git fetch origin
git checkout claude/add-recurring-tasks-5ZheF
git pull origin claude/add-recurring-tasks-5ZheF

# Option C: Atomic deployment (recommended for zero downtime)
# 1. Deploy to new directory
# 2. Switch symlink
# 3. Restart PHP-FPM (if needed)
```

---

### Step 3: Verify Deployment
**Execute these tests immediately after deployment:**

#### Test 1: View Existing Tasks
- Navigate to: `12-week-plan-tasks.php`
- Select any goal and week
- **Expected**: All tasks display normally (no recurring badges yet)
- **If fails**: Check PHP error logs

#### Test 2: Create Non-Recurring Task
- Click "Add Task"
- Enter description WITHOUT checking "Recurring"
- Save
- **Expected**: Task created successfully, appears only in selected week
- **If fails**: Check database and PHP logs

#### Test 3: Create Recurring Task
- Click "Add Task"
- Enter description WITH "Recurring" checkbox checked
- Save
- **Expected**:
  - Success message: "Task added successfully! Recurring task has been copied to all future weeks in this cycle."
  - Task appears in current week and all future weeks
  - Blue "Recurring" badge displayed
- **If fails**: Check if `createRecurringCopies()` method executed

#### Test 4: Edit Existing Task
- Click edit on any task
- Modify description
- Save
- **Expected**: Task updated successfully
- **If fails**: Check if `is_recurring` field is being handled in edit

#### Test 5: Weekly View
- Navigate to: `12-week-weekly.php`
- **Expected**: Recurring tasks show blue "Recurring" badge
- **If fails**: Check template rendering

---

## Rollback Plan (If Something Goes Wrong)

### If Code Deployment Fails (Step 2)
**Action**: Revert application files only
```bash
# Restore previous version of files
git checkout main  # or previous branch
```
**Impact**: Site returns to previous state, database field remains but unused (safe)

### If Database Migration Causes Issues (Step 1)
**Action**: Remove the field (NOT recommended unless critical)
```sql
-- ONLY IF ABSOLUTELY NECESSARY
-- This will break the new code if already deployed
ALTER TABLE tasks DROP COLUMN is_recurring;
DROP INDEX idx_tasks_recurring ON tasks;
```
**Impact**: New code will break, must also revert code deployment

---

## Alternative: Staged Rollout (Recommended for Risk-Averse Deployments)

### Phase 1: Silent Database Update (Week 1)
- Deploy database migration only
- New field exists but not used yet
- Monitor for any performance issues

### Phase 2: Code Deployment (Week 2)
- Deploy application code
- Feature becomes active
- Lower risk since database is stable

---

## Expected Behavior After Deployment

### For Existing Tasks:
- All existing tasks have `is_recurring = 0` (non-recurring)
- Display and functionality unchanged
- Users won't notice any difference

### For New Tasks:
- Users see "Recurring Task" checkbox in Add/Edit modals
- Checking the box creates copies for future weeks
- Blue badge indicates recurring tasks

### Performance Impact:
- Creating a recurring task in week 1: Creates up to 11 additional task records (one per future week)
- Database writes increase slightly (acceptable)
- Index on `is_recurring` ensures query performance remains fast
- Expected query time increase: < 5ms

---

## Monitoring Post-Deployment

### What to Monitor (First 24 Hours):
1. **PHP Error Logs**: Check for SQL errors mentioning `is_recurring`
2. **Database Slow Query Log**: Ensure no performance degradation
3. **User Reports**: Monitor for task creation/editing issues
4. **Task Counts**: Verify recurring tasks are being created correctly

### Warning Signs:
- ❌ SQL errors containing "Unknown column 'is_recurring'"
- ❌ Tasks not saving properly
- ❌ Recurring tasks not appearing in future weeks
- ❌ Database deadlocks or long-running queries

---

## Technical Notes

### Database Lock Duration:
- **ALTER TABLE**: ~1-2 seconds (row lock)
- **CREATE INDEX**: ~2-5 seconds depending on table size
- **Total downtime**: < 10 seconds maximum

### Concurrent User Impact:
- Users viewing tasks: No impact
- Users creating/editing tasks during migration: May see brief delay (1-2 sec)
- Recommendation: Deploy during low-traffic period

### Data Integrity:
- ✅ No data loss risk
- ✅ All existing tasks preserved
- ✅ Backward compatible (old code doesn't break)
- ✅ Forward compatible (new code handles missing field gracefully with defaults)

---

## Success Criteria

Deployment is successful if:
- ✅ All existing tasks remain accessible
- ✅ New non-recurring tasks can be created
- ✅ New recurring tasks copy to future weeks correctly
- ✅ Recurring badge displays properly
- ✅ No PHP errors in logs
- ✅ No SQL errors in database logs
- ✅ Page load times remain normal

---

## Support Contacts

If issues arise during deployment:
- **Database Issues**: Review MySQL error log
- **Application Issues**: Review PHP error log
- **Rollback Decision**: Follow rollback plan above

---

## Post-Deployment Tasks

After successful deployment:
1. Update user documentation (if any)
2. Create internal training materials showing recurring task feature
3. Monitor usage patterns for first week
4. Collect user feedback
5. Plan any necessary adjustments

---

## Estimated Timeline

| Task | Duration | Cumulative |
|------|----------|------------|
| Pre-deployment backup | 5 min | 5 min |
| Database migration | 10 sec | 5 min 10 sec |
| Validate migration | 2 min | 7 min 10 sec |
| Deploy code | 30 sec | 7 min 40 sec |
| Test basic functionality | 5 min | 12 min 40 sec |
| Test recurring feature | 5 min | 17 min 40 sec |
| **Total Deployment Time** | **~20 minutes** | |
| **Actual Downtime** | **< 10 seconds** | |

---

## Conclusion

This deployment is **LOW RISK** if steps are followed in order:
1. ✅ Database migration is non-breaking
2. ✅ Code deployment is backward compatible
3. ✅ Rollback is straightforward if needed
4. ✅ Zero downtime approach is feasible

**Recommendation**: Proceed with deployment following the steps above.
