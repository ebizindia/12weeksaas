<?php
/**
 * Deployment Verification Script
 * Run this script BEFORE and AFTER deployment to verify system health
 *
 * Usage:
 *   Before deployment: php verify_deployment.php --before
 *   After deployment:  php verify_deployment.php --after
 */

// Include necessary files
require_once __DIR__ . '/../inc.php';

use eBizIndia\PDOConn;

// Color output for terminal
function output($message, $type = 'info') {
    $colors = [
        'success' => "\033[0;32m✓ ",
        'error' => "\033[0;31m✗ ",
        'warning' => "\033[0;33m⚠ ",
        'info' => "\033[0;36mℹ ",
    ];
    $reset = "\033[0m";

    echo $colors[$type] . $message . $reset . PHP_EOL;
}

function section($title) {
    echo PHP_EOL . "═══════════════════════════════════════════════════════" . PHP_EOL;
    echo "  " . $title . PHP_EOL;
    echo "═══════════════════════════════════════════════════════" . PHP_EOL;
}

// Parse command line arguments
$mode = isset($argv[1]) && $argv[1] === '--after' ? 'after' : 'before';

section("Deployment Verification - " . strtoupper($mode) . " Deployment");
output("Starting verification checks at " . date('Y-m-d H:i:s'), 'info');

try {
    $conn = PDOConn::getInstance();
    output("Database connection successful", 'success');

    // Check 1: Verify tasks table exists
    section("1. Database Structure Checks");
    $result = $conn->query("SHOW TABLES LIKE 'tasks'");
    if ($result->rowCount() > 0) {
        output("Tasks table exists", 'success');
    } else {
        output("Tasks table NOT found", 'error');
        exit(1);
    }

    // Check 2: Verify is_recurring field
    $result = $conn->query("SHOW COLUMNS FROM tasks LIKE 'is_recurring'");
    $fieldExists = $result->rowCount() > 0;

    if ($mode === 'before') {
        if ($fieldExists) {
            output("is_recurring field already exists (previous deployment?)", 'warning');
        } else {
            output("is_recurring field does not exist yet (expected)", 'success');
        }
    } else { // after mode
        if ($fieldExists) {
            output("is_recurring field exists", 'success');

            // Check field definition
            $fieldInfo = $result->fetch(PDO::FETCH_ASSOC);
            if ($fieldInfo['Type'] === 'tinyint(1)' && $fieldInfo['Null'] === 'NO' && $fieldInfo['Default'] === '0') {
                output("Field definition is correct (TINYINT(1) NOT NULL DEFAULT 0)", 'success');
            } else {
                output("Field definition may be incorrect", 'warning');
                output("  Type: " . $fieldInfo['Type'], 'info');
                output("  Null: " . $fieldInfo['Null'], 'info');
                output("  Default: " . $fieldInfo['Default'], 'info');
            }
        } else {
            output("is_recurring field NOT found (migration failed?)", 'error');
            exit(1);
        }
    }

    // Check 3: Verify index
    if ($mode === 'after') {
        $result = $conn->query("SHOW INDEX FROM tasks WHERE Key_name = 'idx_tasks_recurring'");
        if ($result->rowCount() > 0) {
            output("Index idx_tasks_recurring exists", 'success');
        } else {
            output("Index idx_tasks_recurring NOT found", 'warning');
        }
    }

    // Check 4: Count tasks
    section("2. Data Integrity Checks");
    $result = $conn->query("SELECT COUNT(*) as count FROM tasks");
    $taskCount = $result->fetch(PDO::FETCH_ASSOC)['count'];
    output("Total tasks in database: " . $taskCount, 'info');

    if ($mode === 'after' && $fieldExists) {
        // Count recurring vs non-recurring
        $result = $conn->query("SELECT
            SUM(CASE WHEN is_recurring = 0 THEN 1 ELSE 0 END) as non_recurring,
            SUM(CASE WHEN is_recurring = 1 THEN 1 ELSE 0 END) as recurring
            FROM tasks");
        $counts = $result->fetch(PDO::FETCH_ASSOC);
        output("Non-recurring tasks: " . $counts['non_recurring'], 'info');
        output("Recurring tasks: " . $counts['recurring'], 'info');
    }

    // Check 5: Verify PHP class methods exist
    section("3. Application Code Checks");

    if (class_exists('eBizIndia\\TwelveWeekTasks')) {
        output("TwelveWeekTasks class exists", 'success');

        if (method_exists('eBizIndia\\TwelveWeekTasks', 'saveTask')) {
            output("saveTask() method exists", 'success');
        } else {
            output("saveTask() method NOT found", 'error');
        }

        if (method_exists('eBizIndia\\TwelveWeekTasks', 'getTasks')) {
            output("getTasks() method exists", 'success');
        } else {
            output("getTasks() method NOT found", 'error');
        }

        if ($mode === 'after') {
            if (method_exists('eBizIndia\\TwelveWeekTasks', 'createRecurringCopies')) {
                output("createRecurringCopies() method exists", 'success');
            } else {
                output("createRecurringCopies() method NOT found (old code?)", 'warning');
            }
        }
    } else {
        output("TwelveWeekTasks class NOT found", 'error');
    }

    // Check 6: Verify template files exist
    section("4. Template File Checks");

    $templates = [
        'templates/12-week-plan-tasks.tpl',
        'templates/12-week-weekly.tpl'
    ];

    foreach ($templates as $template) {
        $fullPath = __DIR__ . '/../' . $template;
        if (file_exists($fullPath)) {
            output("$template exists", 'success');

            if ($mode === 'after') {
                $content = file_get_contents($fullPath);
                if (strpos($content, 'is_recurring') !== false) {
                    output("  Template contains is_recurring references", 'success');
                } else {
                    output("  Template missing is_recurring references (old version?)", 'warning');
                }
            }
        } else {
            output("$template NOT found", 'error');
        }
    }

    // Check 7: Test basic functionality (after mode only)
    if ($mode === 'after' && $fieldExists) {
        section("5. Functional Tests");

        // Try a simple SELECT query that the application would run
        try {
            $testSql = "SELECT id, goal_id, week_number, title, weekly_target, is_recurring,
                               mon, tue, wed, thu, fri, sat, sun,
                               is_encrypted, encryption_key_id, created_at, updated_at
                        FROM tasks
                        LIMIT 1";
            $result = $conn->query($testSql);
            output("Sample SELECT query successful", 'success');
        } catch (Exception $e) {
            output("Sample SELECT query FAILED: " . $e->getMessage(), 'error');
        }
    }

    // Summary
    section("Verification Summary");
    if ($mode === 'before') {
        output("System is ready for deployment", 'success');
        output("Next steps:", 'info');
        output("  1. Run the migration: migrations/add_recurring_field.sql", 'info');
        output("  2. Deploy the application code", 'info');
        output("  3. Run this script again with --after flag", 'info');
    } else {
        output("Deployment verification complete", 'success');
        output("System appears to be functioning correctly", 'success');
        output("Recommended: Test creating a recurring task in the UI", 'info');
    }

} catch (Exception $e) {
    output("FATAL ERROR: " . $e->getMessage(), 'error');
    output("Stack trace:", 'error');
    output($e->getTraceAsString(), 'error');
    exit(1);
}

output("Verification completed at " . date('Y-m-d H:i:s'), 'info');
exit(0);
