# Database Migrations

This directory contains database migration scripts for the 12-week goal tracking system.

## How to Use Migrations

### 1. Review the Migration
Before executing, review the SQL file to understand what changes will be made:
```bash
cat add_recurring_field.sql
```

### 2. Backup Your Database
**ALWAYS backup before running migrations:**
```bash
mysqldump -u username -p database_name > backup_$(date +%Y%m%d_%H%M%S).sql
```

### 3. Run Pre-Deployment Verification
```bash
php verify_deployment.php --before
```

### 4. Execute the Migration
**Option A: MySQL Command Line**
```bash
mysql -u username -p database_name < add_recurring_field.sql
```

**Option B: phpMyAdmin**
1. Log into phpMyAdmin
2. Select your database
3. Go to SQL tab
4. Copy and paste the contents of `add_recurring_field.sql`
5. Click "Go"

**Option C: MySQL Workbench**
1. Open MySQL Workbench
2. Connect to your database
3. File → Open SQL Script
4. Select `add_recurring_field.sql`
5. Execute

### 5. Verify Migration Success
```bash
php verify_deployment.php --after
```

### 6. Deploy Application Code
Only after successful migration, deploy the updated application files.

## Available Migrations

### add_recurring_field.sql
**Purpose**: Adds recurring task functionality
**Changes**:
- Adds `is_recurring` column to `tasks` table
- Creates index for performance
- Safe for production (uses DEFAULT 0 for backward compatibility)

**Rollback** (if needed):
```sql
ALTER TABLE tasks DROP COLUMN is_recurring;
DROP INDEX idx_tasks_recurring ON tasks;
```

## Troubleshooting

### "Column already exists" error
The migration was already run. Skip this step.

### "Table doesn't exist" error
Verify you're connected to the correct database.

### Permission errors
Ensure your database user has ALTER and CREATE INDEX privileges:
```sql
GRANT ALTER, CREATE, INDEX ON database_name.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

## Migration Best Practices

1. **Always backup first**
2. **Test on staging/development environment** before production
3. **Run during low-traffic periods** for large tables
4. **Verify success** before deploying code
5. **Have rollback plan ready**

## Support

If you encounter issues:
1. Check MySQL error logs
2. Verify database user permissions
3. Ensure you're on the correct database
4. Review DEPLOYMENT_PLAN.md for detailed guidance
